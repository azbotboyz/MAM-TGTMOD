https://www.tools4noobs.com/online_tools/decrypt/

key: Lyr1cjust4nct
Algorithm: Arcfour
Mode: STREAM
Decode the input using: Hexa