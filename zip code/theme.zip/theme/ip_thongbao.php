<div style="margin-bottom: 10px; float: none; width: 958px; box-shadow: 0 0 5px #DFDFDF; border: 1px solid #CCC; margin-right: 10px; position: relative; display: block; text-shadow: 0px 1px 0px white; -webkit-text-shadow: 0px 1px 0px #FFFFFF; -webkit-border-radius: 3px; border-radius: 3px; color: gray; font-weight: bold; background: url(theme/images/vline.jpg) left -161px repeat-x;">
<div class="h1" style="background: url(theme/images/icon-8.png) no-repeat; background-position: 0 -1035px; color: #333; display: block; height: 30px; line-height: 30px; padding-left: 35px;"><div align="center"><b>
Chào mừng các bạn ghé thăm Nhac.Cuatui.Pro - Chúc các bạn nghe nhạc vui vẻ.
<!--<script>
function setcountdown(theyear,themonth,theday){
yr=theyear;mo=themonth;da=theday
}

setcountdown(2013,2,10)

var occasion="</font><font color='red'>Tết Quý Tỵ - 2013 "
var message_on_occasion="Chào "

var countdownwidth='600px'
var countdownheight='20px'
var countdownbgcolor='lightblack'
var opentags='<font face="Verdana">'
var closetags='</font>'
var montharray=new Array("Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec")
var crosscount=''

function start_countdown(){
if (document.layers)
document.countdownnsmain.visibility="show"
else if (document.all||document.getElementById)
crosscount=document.getElementById&&!document.all?document.getElementById("countdownie") : countdownie
countdown()
}

if (document.all||document.getElementById)
document.write('<span id="countdownie" style="width:'+countdownwidth+'; background-color:'+countdownbgcolor+'"></span>')

window.onload=start_countdown


function countdown(){
var today=new Date()
var todayy=today.getYear()
if (todayy < 1000)
todayy+=1900
var todaym=today.getMonth()
var todayd=today.getDate()
var todayh=today.getHours()
var todaymin=today.getMinutes()
var todaysec=today.getSeconds()
var todaystring=montharray[todaym]+" "+todayd+", "+todayy+" "+todayh+":"+todaymin+":"+todaysec
futurestring=montharray[mo-1]+" "+da+", "+yr
dd=Date.parse(futurestring)-Date.parse(todaystring)
dday=Math.floor(dd/(60*60*1000*24)*1)
dhour=Math.floor((dd%(60*60*1000*24))/(60*60*1000)*1)
dmin=Math.floor(((dd%(60*60*1000*24))%(60*60*1000))/(60*1000)*1)
dsec=Math.floor((((dd%(60*60*1000*24))%(60*60*1000))%(60*1000))/1000*1)
//if on day of occasion
if(dday<=0&&dhour<=0&&dmin<=0&&dsec<=1&&todayd==da){
if (document.layers){
document.countdownnsmain.document.countdownnssub.document.write(opentags+message_on_occasion+closetags)
document.countdownnsmain.document.countdownnssub.document.close()
}
else if (document.all||document.getElementById)
crosscount.innerHTML=opentags+message_on_occasion+closetags
return
}
//if passed day of occasion
else if (dday<=-1){
if (document.layers){
document.countdownnsmain.document.countdownnssub.document.write(opentags+"Occasion already passed! "+closetags)
document.countdownnsmain.document.countdownnssub.document.close()
}
else if (document.all||document.getElementById)
crosscount.innerHTML=opentags+"Occasion already passed! "+closetags
return
}
//else, if not yet
else{
if (document.layers){
document.countdownnsmain.document.countdownnssub.document.write(opentags+dday+ " days, "+dhour+" hours, "+dmin+" minutes, and "+dsec+" seconds left until "+occasion+closetags)
document.countdownnsmain.document.countdownnssub.document.close()
}
else if (document.all||document.getElementById)
crosscount.innerHTML="<font color='blue'>Chỉ Còn:</font><font color='red'> " +opentags+dday+ "</font><font color='blue'>ngày</font> - <font color='red'>"+dhour+"</font><font color='blue'>gi&#7901;</font> - <font color='red'> "+dmin+"</font><font color='blue'>phút</font> - <font color='red'> "+dsec+"</font><font color='blue'>giây nữa là đến =>  "+occasion+closetags
}
setTimeout("countdown()",1000)
}
</script>-->
</b>
</div>
</div></div>