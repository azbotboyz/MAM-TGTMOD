<?php
if (!defined('TGT-MUSIC')) die("Khong co du lieu!");
?>		
               <div class="box2 w_2">
			   <h1><div style="width: 10px; background-color: #FF0099; position: absolute; height: 31px; left: 0; border-right: 1px solid #FAFAFA;"></div>Tin Tức<a style="float: right; color: #000;" href="chuong-trinh/got-talent.html">Xem Thêm</a></h1>

						<?=news_home_1(1);?>
						<?=news_home_2(1);?>
						<div class="clr"></div>   

             
            </div>