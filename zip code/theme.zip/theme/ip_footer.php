    <div id="footer">
    <div class="adv_footer"><?=BANNER('banner_footer','990');?></div>

     <!--       </div>
            <div class="clr"></div> 
            <!--    <div class="link-group">
                    <p class="link-group-title">Hỗ trợ Online</p>
                    <ul>
		               <li><a href="#">Giới Thiệu</a></li>
                    </ul>
                </div><!--End .link-group -->
         <!--        <div class="link-group">
                    <p class="link-group-title">Quảng Cáo</p>
                    <ul>
                       <li><a href="#">Quảng Cáo</a></li>
                    </ul>
                </div><!--End .link-group -->
         <!--        <div class="link-group">
                    <p class="link-group-title">Quy định</p>
                    <ul>
                       <li><a href="#">Quy định</a></li>
                    </ul>
                </div><!--End .link-group -->
         <!--        <div class="link-group">
                    <p class="link-group-title">Liên hệ</p>
                    <ul>
                       <li><a href="#">wWw.ONER.VN</a></li>
                    </ul>
                </div><!--End .link-group -->
        <!--         <div class="link-group">
                    <p class="link-group-title">Vnexpress</p>
                    <ul>
                       <li><a href="http://vnexpress.net">Home</a></li>
                    </ul>
                </div><!--End .link-group -->
        <!--         <div class="link-group last-child">
                    <p class="link-group-title">SAO ONLINE</p>
                    <ul>
                       <li><a href="http://ngoisao.net/">Ngôi sao</a></li>
                    </ul>
                </div><!--End .link-group --> 
               <!--  <div class="clr"></div>
            </div>
            <div class="clr"></div> -->
            <div class="copyright">
            © Copyright 2016 , all rights reserved - Powered by IPOS 1.0<br />
              Add : Bình Dương - Việt Nam. <br />
Contact : Doan Nguyen - Hotline: 0974.858.395 - Email : nguyenthanhdoan1992@gmail.com  <br />
            </div>
			<div class="author">Đây là phiên bản thử nghiệm chưa chính thức.</div>
            <div class="clr"></div>
    </div>
	<div class="clr"></div>

</div>
<div class="gop-y"><a href="lien-he.html"><img src="images/gopy.jpg" border="0" /></a></div>
