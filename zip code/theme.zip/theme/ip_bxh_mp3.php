			<div class="box2 w_3">
            	<h1 class="title bxh_icon_s" id="tab_click_top_song"> BXH Bài hát 
				<a onClick="return BXS('bxh_ca',10,this); return false;">Hàn Quốc</a>
				<a onClick="return BXS('bxh_am',10,this); return false;">Âu Mỹ</a>
				<a class="activer" onClick="return BXS('bxh_vn',10,this); return false;">Việt Nam</a></h1>
                <div class="padding"id="load_bxs">
                    <?=top_song('bxh_vn',10);?>
                </div>
            </div>