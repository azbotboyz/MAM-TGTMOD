        	<div class="box2 w_3">
            	<h1 class="bxh_icon_a" id="tab_click_top_album">BXH Album<a onClick="return XHAlbum('bxhpl_ca',5,this); return false;">Hàn Quốc</a><a onClick="return XHAlbum('bxhpl_am',5,this); return false;">Âu Mỹ</a><a class="activer" onClick="return XHAlbum('bxhpl_vn',5,this); return false;">Việt Nam</a></h1>
                <div class="padding"id="load_bxhpl">
                    <?=top_song('bxhpl_vn',5);?>
                </div>
            </div>