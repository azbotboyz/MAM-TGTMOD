			<div class="box w_3">
                     <div id="fb-root"></div>
			<div class="fb-like-box" data-href="<?=FACE_PAGE;?>" data-width="345" data-height="320" data-colorscheme="light" data-show-faces="true" data-header="true" data-stream="false" data-show-border="true"></div>
                </div>

