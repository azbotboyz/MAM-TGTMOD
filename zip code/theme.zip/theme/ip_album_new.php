        	<div class="box2 w_4">
            	<h1 class="album_icon_new" id="tab_click_album">Album mới<a href="javascript:void(0);" onClick="return AlbumNEW(2,0,this); return false;">Âu Mỹ</a><a href="javascript:void(0);" onClick="return AlbumNEW(3,0,this); return false;">Hàn Quốc</a><a class="activer" href="javascript:void(0);" onClick="return AlbumNEW(1,0,this); return false;">Việt Nam</a></h1>
                <div class="padding">
					<div class="new_album_bg" id="load_album">
						<?=album_new(1,0);?>
                    </div>
                </div>
            </div>
