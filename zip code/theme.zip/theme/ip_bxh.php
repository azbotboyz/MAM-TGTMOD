                    <div class="menu_left">
                    <div class="title bxh_m">BXH Nhạc</div>
                    <ul class="singer_">
                                    <li><a href="BXH/bai-hat/Viet-Nam.html" title="Bảng xếp hạng bài hát Việt Nam">Việt Nam</a></li>
                                    <li><a href="BXH/bai-hat/Au-My.html" title="Bảng xếp hạng bài hát Âu Mỹ">Âu Mỹ</a></li>
                                    <li><a href="BXH/bai-hat/Han-Quoc.html" title="Bảng xếp hạng bài hát Hàn Quốc"> Hàn Quốc</a></li>
                    </ul>
                    </div>
                    <div class="menu_left">
                    <div class="title bxh_v">BXH Video</div>
                    <ul class="singer_">
                                    <li><a href="BXH/Video/Viet-Nam.html" title="Bảng xếp hạng bài hát Việt Nam">Việt Nam</a></li>
                                    <li><a href="BXH/Video/Au-My.html" title="Bảng xếp hạng bài hát Âu Mỹ">Âu Mỹ</a></li>
                                    <li><a href="BXH/Video/Han-Quoc.html" title="Bảng xếp hạng bài hát  Hàn Quốc"> Hàn Quốc</a></li>
                    </ul>
                    </div>
                    <div class="menu_left">
                    <div class="title bxh_v">BXH Album</div>
                    <ul class="singer_">
                                    <li><a href="BXH/Album/Viet-Nam.html" title="Bảng xếp hạng bài hát Việt Nam">Việt Nam</a></li>
                                    <li><a href="BXH/Album/Au-My.html" title="Bảng xếp hạng bài hát Âu Mỹ">Âu Mỹ</a></li>
                                    <li><a href="BXH/Album/Han-Quoc.html" title="Bảng xếp hạng bài hát  Hàn Quốc"> Hàn Quốc</a></li>
                    </ul>
                    </div>					