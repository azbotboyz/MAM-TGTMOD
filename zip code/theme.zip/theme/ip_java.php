<meta name="robots" content="index, follow" />
<link href="images/favicon.ico" rel="shortcut icon" />
<link href="./theme/css/styles.css" rel="stylesheet" type="text/css" />
<link href="./theme/css/skin.css" rel="stylesheet" type="text/css" />
<link href="script/jquery.autocomplete.css" rel="stylesheet" type="text/css" />
<!--good share-->
<link href="./theme/css/goodshare-color.min.css" rel="stylesheet">
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/jquery.goodshare.js/3.2.5/goodshare.min.js"></script>
<script type="text/javascript" src="theme/js/ichphienpro.js"></script>
<script type="text/javascript" src="script/dropmenu.js"></script> 
<script type="text/javascript" src="script/jquery.cookie.js"></script>
<script type="text/javascript" src="theme/js/jquery.boxy.js"></script>
<script type="text/javascript" src="theme/js/jquery.id.js"></script>
<script>var mainURL = "<? echo SITE_LINK;?>";</script>
<script type="text/javascript" src="script/ajax_load.js"></script>
<script type='text/javascript' src='script/jquery.autocomplete.js'></script>
<script type='text/javascript' src='jwplayer-7.3.5/jwplayer.js'></script>
<script>jwplayer.key="ToBhmLOmr3Vm64Xv9v5hsTJYHo+Am/8sWXAGTA==";</script>
<script type='text/javascript' src="script/APlayer.min.js"></script>

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v2.5&appId=228946680635441";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>