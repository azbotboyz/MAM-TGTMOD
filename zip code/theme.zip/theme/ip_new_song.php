        	<div class="box2 w_4">
            	<h1 class="songs_icon_new" id="tab_click_new_song">Bài Hát Mới, Hot
				<a onClick="return BXH('new_ca',10,this); return false;">Hàn Quốc</a>
				<a onClick="return BXH('new_am',10,this); return false;">Âu Mỹ</a>
				<a class="activer" onClick="return BXH('new_vn',10,this); return false;">Việt Nam</a></h1>
                <div class="padding" id="load_new_song">
					<?=top_song('new_vn',10);?>
                </div>
            </div>