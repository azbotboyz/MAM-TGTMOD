<div style="margin-bottom: 10px; float: none; width: 100%; box-shadow: 0 0 5px ; border: 1px solid #CCC; margin-right: 10px; position: relative; display: block; text-shadow: 0px 1px 0px white;  -webkit-border-radius: 3px; border-radius: 3px; color: gray; font-weight: bold; background: url(theme/images/vline.jpg) left -161px repeat-x;">
<div class="h1" style="background: url(theme/images/icon-8.png) no-repeat; background-position: 0 -1035px; display: block; height: 30px; line-height: 30px; padding-left: 35px;">
					<font color="blue"> <b>Nghe Nhạc Online Chất Lượng Cao - Tải Nhạc Nhanh - Upload, Chia Sẻ Nhạc Mọi Lúc Mọi Nơi!</b></font>
		
</div></div>