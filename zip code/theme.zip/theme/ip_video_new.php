        	<div class="box2 w_4">
            	<h1 class="video_icon_new" id="tab_click_video">Video Mới<a href="javascript:void(0);" onClick="return VideoNEW(3,this); return false;">Hàn Quốc</a><a href="javascript:void(0);" onClick="return VideoNEW(2,this); return false;">Âu Mỹ</a><a class="activer" href="javascript:void(0);" onClick="return VideoNEW(1,this); return false;">Việt Nam</a></h1>
                <div class="padding">
					<div class="new_video_bg" id="load_video">
						<?=video_new(1);?>
                    </div>
                </div>
            </div>
