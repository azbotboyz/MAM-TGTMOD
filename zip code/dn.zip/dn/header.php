<?php

define('TGT-MUSIC',true);

include("../tgt/tgt_music.php");

?>

<link href="styles/style.css" rel="stylesheet" rev="stylesheet">

<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0">

<table width="100%" height="65" border="0" cellspacing="0" cellpadding="0">

  <tr>

    <td width="50%" align="left" background="./images/bg_top.png" height="60" style="padding-left:10px; ">

    <img src="images/logo.png">

    </td>

    <td align="right" valign="top" background="./images/bg_top.png" style="padding-top: 10px; padding-right: 20px;"><? echo VER;?> code by ichphienpro | <a href="xoa_cache.php" target="_blank">Trang chủ</a></td>

  </tr>

  <tr>
    <td colspan="2" class="style_border" height="5"></td>

  </tr>

</table>

</body>