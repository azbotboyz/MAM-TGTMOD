<?php
define('TGT-MUSIC',true);
include("../tgt/tgt_music.php");
DeleteCache(PATH,$rf=1);
?>