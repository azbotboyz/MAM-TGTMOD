find Find/Replace trong regular expression
:([0-9]+)([0-9]+)"
.\111"