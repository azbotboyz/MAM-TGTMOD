
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en-US" xmlns:fb="http://www.facebook.com/2008/fbml" xmlns:og="http://opengraphprotocol.org/schema/">
    <head>
        <link rel="icon" type="image/png" href="http://stc.id.nixcdn.com/v11/images/favicon.ico" />
        <meta name="viewport" content="width=668, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />  
        <meta http-equiv="Content-Language" content="vi" />
        <meta http-equiv="X-UA-Compatible" content="requiresActiveX=true"/>
        <title>Sầu Tím Thiệp Hồng - Quang Lê | Chất Lượng 320kbps</title>
        <meta property="og:description" content="Sau Tim Thiep Hong Quang Le - Nghe online tốc độ cao bài hát SầuTím Thiệp Hồng Quang Lê MP3 320kbps.Tải ca khúc trữ tình chọn lọc này làm nhạc chờ" />
        <meta content="Nghe Ca Khúc Sầu Tím Thiệp Hồng - Quang Lê, Tải bài Hát Sầu Tím Thiệp Hồng - Quang Lê chất lượng 320kbps,Abum Quang Lê, Quang Lê Mp3,Quang Lê Tuyển Chọn" name="keywords" />
        <link rel="canonical" href="http://www.nhaccuatui.com/bai-hat/sau-tim-thiep-hong-le-quyen-ft-quang-le.367fYBSxm8Cr.html" />
        <link rel="alternate" media="handheld" href="http://m.nhaccuatui.com/bai-hat/sau-tim-thiep-hong-le-quyen-ft-quang-le.367fYBSxm8Cr.html" />
        <meta content="index, follow" name="robots" />
        <meta content="Sau Tim Thiep Hong Quang Le - Nghe online tốc độ cao bài hát SầuTím Thiệp Hồng Quang Lê MP3 320kbps.Tải ca khúc trữ tình chọn lọc này làm nhạc chờ" name="description" />            
        <link rel="stylesheet" type="text/css" media="screen, print, projection" href="http://stc.id.nixcdn.com/v11/css/loading.css"/>        
        <link rel="stylesheet" type="text/css" media="screen, print, projection" href="http://stc.id.nixcdn.com/v11/css/nct.screen.v11.0.31.css"/>                
        <!--[if IE ]><link rel="stylesheet" type="text/css" media="screen, print, projection" href="http://stc.id.nixcdn.com/v11/css/fixie.css"/><![endif]-->                
        <script type="text/javascript">
            document.domain = "http://localhost/tgt2016";
            var NCTInfo = {"ROOT_URL": "http://localhost/tgt2016/", "STATIC_URL": "http://stc.id.nixcdn.com/v11/", "WIDGET_URL" : "http://widget.nhaccuatui.com/", "SSO_URL": "https://sso.nct.vn/", "INTERACTION_URL": "http://www.nhaccuatui.com/interaction/", "isLogged": "false", "userName": "", "userId": "0", "mineKey": "", "avatar": "http://stc.id.nixcdn.com/v11/images/avatar_default.jpg", "upl": [], "upll": []};
            var _gaq = _gaq || [];
            
        </script>
        <script type="text/javascript" src="http://stc.id.nixcdn.com/v11/js/nct.core.min.v1.2.js"></script>
        <script type="text/javascript" src="http://stc.id.nixcdn.com/v11/js/pack/embed/1.0.1.embed.js"></script>   
        
        
        <style>
            html, body {height: 100%;}
        </style>
    </head>
    <body style="min-width: inherit; height: 100%;">
        



<style>
    .playing_absolute {width: 668px; height: 312px;}
    @media screen and (max-width: 350px){
        .playing_absolute {width: 316px; height: 381px;}
    }
</style>
<div class="playing_absolute">
    
    
    <link rel="stylesheet" type="text/css" media="screen, print, projection" href="http://stc.id.nixcdn.com/v11/html5/nct-player-mp3/css/style_mp3.0.1.css"/>
    <script type="text/javascript" src="http://stc.id.nixcdn.com/v11/html5/nct-player-mp3/version/0.19.js"></script>
    <div class="flash_playing" id="flashPlayer"></div>
    <script type="text/javascript">
    isEmbed = true;
    if (putils.support.tagAudio()) {
        var player = new NCTPlayer();
        player.peConfig.autoPlay = false;
        player.adsMp3.link = "http://api.nas.nct.vn/v2/ads?zl=S_Inner";
        player.adsMp3.open = true;
        player.peConfig.xmlURL = "http://localhost/tgt2016/xml/sautimthiephong.xml";
        player.peConfig.defaultIndex = "0";
        player.load("flashPlayer");
        NCTNowPlaying.type = "song";
    } else {
        var player = {};
        player.open = false;
        document.write('<object data="http://stc.id.nixcdn.com/v11/flash/playermp3.nct.11.0.3.swf" id="mediaFlashPlayer" classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" name="mediaFlashPlayer" type="application/x-shockwave-flash" width="668" height="312" style="float:left;"><param name="movie" value="http://stc.id.nixcdn.com/v11/flash/playermp3.nct.11.0.3.swf" /><param name="quality" value="high" /><param name="scale" value="noscale" /><param name="wmode" value="transparent" /><param name="allowscriptaccess" value="always" /><param name="allowFullScreen" value="true" /><param name="allownetworking" value="all" /><param name="bgcolor" value="#000000" /><param name="flashvars" value="flashid=mediaFlashPlayer&amp;autostart=true&amp;ads=http://api.nas.nct.vn/v2/ads?zl=S_Inner&amp;defaultindex=0&amp;file=http://localhost/tgt2016/xml/sautimthiephong.xml" /><embed id="mediaFlashPlayer" bgcolor="#000000" allownetworking="all" scale="noscale" quality="high" wmode="transparent" allowscriptaccess="always" allowfullscreen="true" width="668" height="312" src="http://stc.id.nixcdn.com/v11/flash/playermp3.nct.11.0.3.swf" flashvars="flashid=mediaFlashPlayer&amp;autostart=true&amp;ads=http://api.nas.nct.vn/v2/ads?zl=S_Inner&amp;defaultindex=0&amp;file=http://localhost/tgt2016/xml/sautimthiephong.xml" /></object>');
        NCTNowPlaying.intFlashPlayer("flashPlayer", "song", "f0c8a9fcfd69697a66854b1fb333c530");
        var dataSong = {key: '367fYBSxm8Cr', type: 'song'};
    }
    </script>
    
    
</div>
<script type="text/javascript">       
    $(document).ready(function() {
        NCTNowPlaying.initNowPlaying();
        NCT_widget_exec();
        NCTWidget.hitCounter('2454490', '1475676897342', '88b3d540b727618d16bf74194c46bc34', "song");     
        if ($("#mp3flashPlayer").size() > 0) {
            document.getElementById("mp3flashPlayer").play();
        }
    });
</script>
        <script type="text/javascript">
        var _gaq = _gaq || [];
    _gaq.push(['_setAccount', 'UA-273986-1']);
    _gaq.push(['_trackPageview']);
    //_gaq.push(['nct._setAccount', 'UA-273986-19']);
    //_gaq.push(['nct._setDomainName', 'nhaccuatui.com']);
    //_gaq.push(['nct._trackPageview']);
    (function () {
        var ga = document.createElement('script');
        ga.type = 'text/javascript';
        ga.async = true;
        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0];
        s.parentNode.insertBefore(ga, s);
    })();</script>
        <script type="text/javascript" src="http://stc.nas.nixcdn.com/js/nqc.min.v-2.0.4.js"></script>
    </body>
</html>

