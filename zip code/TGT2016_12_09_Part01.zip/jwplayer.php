
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns='http://www.w3.org/1999/xhtml'>
<head>
<script src="http://area51.3playmedia.com/p3123/jwplayer-7.0.2/jwplayer.js"></script>
<script>jwplayer.key="8pp8BDk8MDsWow263DMaGA2wD03vxEYVTs6/tg==";</script>

</head>
<body>
<div id='myElement'>Loading the player ...</div>
<script type='text/javascript'>
var playerInstance = jwplayer('myElement');
playerInstance.setup({
  playlist: "http://localhost/tgt2016/xml/Playlist2.xml",
  width: 640,
  height: 360
});
</script>
</body>
</html>