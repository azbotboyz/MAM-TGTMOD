<div class="footer">
    <p><a href="<? echo SITE_LINK ?>/mobile" title="Mobile">Mobile</a>  |  <a href="<? echo SITE_LINK ?>" rel="nofollow" title="Desktop">Desktop</a></p>
    Copyright © 2014 IPOS 1.0 - Edit by tuannvbg@gmail.com
</div>