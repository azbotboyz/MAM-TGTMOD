<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="apple-itunes-app" content="app-id=433852509, app-argument=https://itunes.apple.com/us/app/nhaccuatui/id433852509?ls=1&mt=8" />
<link rel="icon" type="image/png" href="http://stc.m.nixcdn.com/images/favicon.ico" />
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no" />
<link href="http://stc.m.nixcdn.com/css/screen.0.1.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
	var NCTInfo = {"ROOT_URL": "http://m.nhaccuatui.com/"};
</script>
<script type="text/javascript" src="http://stc.m.nixcdn.com/js/core.0.2.js"></script>
<script type="text/javascript" src="http://stc.m.nixcdn.com/js/flash_detect.0.1.js"></script>  
<script type="text/javascript" src="http://stc.m.nixcdn.com/js/exec.0.4.js"></script>
